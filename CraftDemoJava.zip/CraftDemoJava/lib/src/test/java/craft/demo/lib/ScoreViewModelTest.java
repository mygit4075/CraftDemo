/*
 * Copyright (C) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package craft.demo.lib;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.LinkedList;
import java.util.List;

import craft.demo.lib.model.Repository;
import craft.demo.lib.model.room.User;
import craft.demo.lib.modelview.ScoreViewModel;

import static org.mockito.Mockito.when;

public class ScoreViewModelTest {

    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();

    @Mock
    private Repository mRepository;

    private ScoreViewModel mViewModel;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        mViewModel = new ScoreViewModel(mRepository);
    }

    @Test
    public void getAllUsers_whenNoUserSaved() {
        MutableLiveData<List<User>> usersLiveData = new MutableLiveData<>();
        usersLiveData.setValue(new LinkedList<>());
        when(mRepository.getAllUsers()).thenReturn(usersLiveData);

        //When getting the user name
        LiveData<List<User>> savedUsers = mViewModel.getAllUsers();
        Assert.assertTrue(savedUsers.getValue().isEmpty());
    }

    @Test
    public void getUserName_whenUserSaved() {
        // Given that the UserDataSource returns a user
        User user = new User(1, "name", 877);
        MutableLiveData<List<User>> usersLiveData = new MutableLiveData<>();
        List<User> usersList = new LinkedList<>();
        usersList.add(user);
        usersLiveData.setValue(usersList);
        when(mRepository.getAllUsers()).thenReturn(usersLiveData);

        //When getting the user name
        LiveData<List<User>> savedUsers = mViewModel.getAllUsers();
        User savedUser = savedUsers.getValue().get(0);
        Assert.assertEquals(1, savedUser.uid);
        Assert.assertEquals("name", savedUser.name);
        Assert.assertEquals(877, savedUser.score);
    }

}
