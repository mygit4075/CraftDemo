/*
 * Copyright (C) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package craft.demo.lib;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.room.Room;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import craft.demo.lib.model.room.User;
import craft.demo.lib.model.room.UserDatabase;

@RunWith(AndroidJUnit4.class)
public class UserDaoTest {

    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();

    private static final User USER = new User(23, "username", 456);

    private UserDatabase mDatabase;

    @Before
    public void initDb() {
        // using an in-memory database because the information stored here disappears when the
        // process is killed
        mDatabase = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(),
                UserDatabase.class)
                // allowing main thread queries, just for testing
                .allowMainThreadQueries()
                .build();
    }

    @After
    public void closeDb() {
        mDatabase.close();
    }

    @Test
    public void getUsersWhenNoUserInserted() throws InterruptedException {
        Assert.assertTrue(LiveDataTestUtil.<List<User>>getOrAwaitValue(mDatabase.userDao().getAll()).isEmpty());
    }

    @Test
    public void insertAndGetUser() throws InterruptedException {
        mDatabase.userDao().insertOrUpdateUsers(USER);
        List<User> userList = LiveDataTestUtil.<List<User>>getOrAwaitValue(mDatabase.userDao().getAll());
        Assert.assertEquals(1, userList.size());
        User user = userList.get(0);
        Assert.assertEquals(23, user.uid);
        Assert.assertEquals("username", user.name);
        Assert.assertEquals(456, user.score);
    }

    @Test
    public void updateAndGetUser() throws InterruptedException {
        mDatabase.userDao().insertOrUpdateUsers(USER);

        User updatedUser = new User(USER.uid, "new username", 457);
        mDatabase.userDao().insertOrUpdateUsers(updatedUser);
        List<User> userList = LiveDataTestUtil.<List<User>>getOrAwaitValue(mDatabase.userDao().getAll());
        Assert.assertEquals(1, userList.size());
        User user = userList.get(0);
        Assert.assertEquals(23, user.uid);
        Assert.assertEquals("new username", user.name);
        Assert.assertEquals(457, user.score);
    }

    @Test
    public void deleteAndGetUser() throws InterruptedException {
        mDatabase.userDao().insertOrUpdateUsers(USER);

        mDatabase.userDao().deleteAll();
        List<User> userList = LiveDataTestUtil.<List<User>>getOrAwaitValue(mDatabase.userDao().getAll());
        Assert.assertTrue(userList.isEmpty());
    }
}
