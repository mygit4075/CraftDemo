package craft.demo.util;

import android.util.Log;

/**
 * Utility for logging
 */
public class Logger {

    private Logger() {
        //It's utility class, hence preventing users from creating instances of it.
    }

    public static void d(String tag, String msg) {
        Log.d(tag, msg);
    }
}
