package craft.demo.lib.model;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

import craft.demo.lib.model.room.User;
import craft.demo.lib.model.room.UserDao;
import craft.demo.lib.model.room.UserDatabase;

public class Repository {

    private final UserDao mUserDao;

    public Repository(UserDao userDao) {
        mUserDao = userDao;
    }

    public LiveData<List<User>> getAllUsers() {
        return mUserDao.getAll();
    }

    public void insertUsers(List<User> users) {
        UserDatabase.databaseWriteExecutor.execute(() -> {
            mUserDao.insertOrUpdateUsers(users);
        });
    }

    public void updateUsers(List<User> users) {
        UserDatabase.databaseWriteExecutor.execute(() -> {
            mUserDao.insertOrUpdateUsers(users);
        });
    }

    public void deleteUsers(List<User> users) {
        UserDatabase.databaseWriteExecutor.execute(() -> {
            mUserDao.deleteUsers(users);
        });
    }

    public void deleteAll() {
        UserDatabase.databaseWriteExecutor.execute(() -> {
            mUserDao.deleteAll();
        });
    }
}
