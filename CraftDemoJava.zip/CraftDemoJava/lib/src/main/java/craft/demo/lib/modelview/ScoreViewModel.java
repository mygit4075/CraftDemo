package craft.demo.lib.modelview;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import craft.demo.lib.model.Repository;
import craft.demo.lib.model.room.User;

public class    ScoreViewModel extends ViewModel {

    private final Repository mRepository;

    public ScoreViewModel(Repository repository) {
        mRepository = repository;
    }

    public LiveData<List<User>> getAllUsers() {
        return mRepository.getAllUsers();
    }

}
