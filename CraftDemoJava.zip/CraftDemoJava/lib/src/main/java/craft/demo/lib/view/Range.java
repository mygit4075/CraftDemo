package craft.demo.lib.view;

public class Range {

    public final int mStart;
    public final int mEnd;
    public double mPercentage;

    public Range(int start, int end, double percentage){
        this.mStart = start;
        this.mEnd = end;
        this.mPercentage = percentage;
    }

}
