package craft.demo.lib.view;

public class RangeConverter {

    static int[][] convert(String[] stringArray) throws NumberFormatException {
        int[][] retVal = new int[stringArray.length][2];
        int i = 0;
        for (String str : stringArray) {
            String[] ranges = str.split("-");
            if (ranges.length == 2) {
                retVal[i][0] = Integer.parseInt(ranges[0]);
                retVal[i][1] = Integer.parseInt(ranges[1]);
                if (retVal[i][0] > retVal[i][1]) {
                    throw new IllegalArgumentException("Range start : " + retVal[i][0] + " is greater than end : " + retVal[i][1]);
                }
                i++;
            } else {
                throw new IllegalArgumentException(str + "is not in the form of <start-end>");
            }
        }
        return retVal;
    }

}
