package craft.demo.lib.model.room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity( tableName = "users")
public class User {

    @PrimaryKey
    public int uid;

    @ColumnInfo( name = "name")
    public String name;

    @ColumnInfo( name = "score")
    public int score;

    public User(){}

    public User( int uid, String name, int score) {
        this.uid = uid;
        this.name = name;
        this.score= score;
    }
}
