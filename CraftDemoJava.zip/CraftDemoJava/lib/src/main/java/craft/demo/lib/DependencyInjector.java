package craft.demo.lib;

import android.content.Context;

import craft.demo.lib.model.Repository;
import craft.demo.lib.model.room.UserDatabase;
import craft.demo.lib.modelview.ScoreViewModelFactory;

public class DependencyInjector {

    public static Repository provideRepository(Context context) {
        UserDatabase database = UserDatabase.getDatabase(context);
        return new Repository(database.userDao());
    }

    public static ScoreViewModelFactory provideViewModelFactory(Context context) {
        Repository repository = provideRepository(context);
        return new ScoreViewModelFactory(repository);
    }

}
