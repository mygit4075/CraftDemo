package craft.demo.lib.modelview;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import craft.demo.lib.model.Repository;

public class ScoreViewModelFactory implements ViewModelProvider.Factory {

    private final Repository mRepository;

    public ScoreViewModelFactory( Repository repository) {
        this.mRepository = repository;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new ScoreViewModel( mRepository );
    }
}
