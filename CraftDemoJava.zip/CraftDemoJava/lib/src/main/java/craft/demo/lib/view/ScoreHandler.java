package craft.demo.lib.view;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import craft.demo.lib.model.room.User;

class ScoreHandler {
    private List<User> mUsers;
    private List<Range> mRanges;

    ScoreHandler(int[][] rangeValues) {
        //Sort the ranges in descending order
        Arrays.sort(rangeValues, (int[] a, int[] b) -> b[0] - a[0]);
        mRanges = new LinkedList<>();
        for (int[] rangeVal : rangeValues) {
            Range range = new Range(rangeVal[0], rangeVal[1], 0.0);
            mRanges.add(range);
        }
    }

    List<Range> getRanges() {
        return mRanges;
    }

    List<Range> handle(List<User> users) {
        if (users == null) {
            for (Range range : mRanges) {
                range.mPercentage = 0.0;
            }
        } else {
            if (mUsers != null && mUsers.equals(users)) {
                return mRanges;
            } else {
                for (Range range : mRanges) {
                    range.mPercentage = 0.0;
                }

                int count = users.size();
                for (User user : users) {
                    for (Range range : mRanges) {
                        if (user.score >= range.mStart && user.score <= range.mEnd) {
                            range.mPercentage++;
                        }
                    }
                }

                if (count > 0) {
                    for (Range range : mRanges) {
                        range.mPercentage = (range.mPercentage * 100) / count;
                    }
                }
            }
        }

        mUsers = users;
        return mRanges;
    }

}
