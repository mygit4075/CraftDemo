package craft.demo.lib.view;

import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import java.util.Date;
import java.util.List;

import craft.demo.lib.DependencyInjector;
import craft.demo.lib.R;
import craft.demo.lib.databinding.OverviewBinding;
import craft.demo.lib.modelview.ScoreViewModel;
import craft.demo.lib.modelview.ScoreViewModelFactory;

public class MyScoreFragment extends Fragment {

    private static String TAG = MyScoreFragment.class.getName();
    private OverviewBinding mOverviewBinding;
    private int mScore;
    private ScoreHandler mScoreHandler;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mOverviewBinding = OverviewBinding.inflate(inflater, container, false);
        return mOverviewBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Bundle bundle = getArguments();
        mScore = 0;
        String[] rangeArray = getResources().getStringArray(R.array.range_values);
        mScoreHandler = new ScoreHandler(RangeConverter.convert(rangeArray));
        if (bundle != null) {
            mScore = bundle.getInt("Score", 0);
        }

        ScoreViewModelFactory factory = DependencyInjector.provideViewModelFactory(getActivity().getApplicationContext());
        ScoreViewModel scoreViewModel = new ViewModelProvider(this, factory).get(ScoreViewModel.class);
        scoreViewModel.getAllUsers().observe(getViewLifecycleOwner(), users -> {
            updateScore(mScoreHandler.handle(users));
        });
        mOverviewBinding.ranges.cat1.background.setBackgroundColor(getResources().getColor(R.color.cat1));
        mOverviewBinding.ranges.cat1.range.setText(rangeArray[0]);
        mOverviewBinding.ranges.cat2.background.setBackgroundColor(getResources().getColor(R.color.cat2));
        mOverviewBinding.ranges.cat2.range.setText(rangeArray[1]);
        mOverviewBinding.ranges.cat3.background.setBackgroundColor(getResources().getColor(R.color.cat3));
        mOverviewBinding.ranges.cat3.range.setText(rangeArray[2]);
        mOverviewBinding.ranges.cat4.background.setBackgroundColor(getResources().getColor(R.color.cat4));
        mOverviewBinding.ranges.cat4.range.setText(rangeArray[3]);
        mOverviewBinding.ranges.cat5.background.setBackgroundColor(getResources().getColor(R.color.cat5));
        mOverviewBinding.ranges.cat5.range.setText(rangeArray[4]);

        DateFormat df = new DateFormat();
        mOverviewBinding.analysis.date.setText(getString(R.string.date_text, df.format(getString(R.string.date_format), new Date())));
        mOverviewBinding.analysis.scoreVal.setText(String.valueOf(mScore));
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void updateScore(List<Range> rangeList) {
        mOverviewBinding.ranges.cat1.indicator.setVisibility(View.INVISIBLE);
        mOverviewBinding.ranges.cat2.indicator.setVisibility(View.INVISIBLE);
        mOverviewBinding.ranges.cat3.indicator.setVisibility(View.INVISIBLE);
        mOverviewBinding.ranges.cat4.indicator.setVisibility(View.INVISIBLE);
        mOverviewBinding.ranges.cat5.indicator.setVisibility(View.INVISIBLE);
        mOverviewBinding.analysis.progressBar.setProgress((int) mScore / 10);
        for (int i = 0; i < rangeList.size(); i++) {
            Range range = rangeList.get(i);
            int color = -1;
            TextView indicator = null;
            if (i == 0) {
                if (range.mStart <= mScore && range.mEnd >= mScore) {
                    indicator = mOverviewBinding.ranges.cat1.indicator;
                }
                mOverviewBinding.ranges.cat1.percentage.setText(String.format(getString(R.string.percentage_format), range.mPercentage));
                color = R.color.cat1;
            } else if (i == 1) {
                if (range.mStart <= mScore && range.mEnd >= mScore) {
                    indicator = mOverviewBinding.ranges.cat2.indicator;
                }
                mOverviewBinding.ranges.cat2.percentage.setText(String.format(getString(R.string.percentage_format), range.mPercentage));
                color = R.color.cat2;
            } else if (i == 2) {
                if (range.mStart <= mScore && range.mEnd >= mScore) {
                    indicator = mOverviewBinding.ranges.cat3.indicator;
                }
                mOverviewBinding.ranges.cat3.percentage.setText(String.format(getString(R.string.percentage_format), range.mPercentage));
                color = R.color.cat3;
            } else if (i == 3) {
                if (range.mStart <= mScore && range.mEnd >= mScore) {
                    indicator = mOverviewBinding.ranges.cat4.indicator;
                }
                mOverviewBinding.ranges.cat4.percentage.setText(String.format(getString(R.string.percentage_format), range.mPercentage));
                color = R.color.cat4;
            } else if (i == 4) {
                if (range.mStart <= mScore && range.mEnd >= mScore) {
                    indicator = mOverviewBinding.ranges.cat5.indicator;
                }
                mOverviewBinding.ranges.cat5.percentage.setText(String.format(getString(R.string.percentage_format), range.mPercentage));
                color = R.color.cat5;
            }

            if (indicator != null) {
                indicator.setVisibility(View.VISIBLE);
                indicator.setText(String.valueOf(mScore));
                mOverviewBinding.analysis.progressBar.setIndicatorColor(getResources().getColor(color));
            }
        }
    }
}
