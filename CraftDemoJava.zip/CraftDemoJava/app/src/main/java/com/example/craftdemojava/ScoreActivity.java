package com.example.craftdemojava;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import craft.demo.lib.view.MyScoreFragment;

public class ScoreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bundle bundle = new Bundle();
        bundle.putInt("Score", 787);
        getSupportFragmentManager().beginTransaction().
                setReorderingAllowed(true).
                add(R.id.fragment_container_view, MyScoreFragment.class, bundle).
                commit();
    }

}