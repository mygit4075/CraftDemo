package com.example.craftdemojava;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.craftdemojava.databinding.TestFragmentBinding;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import craft.demo.lib.DependencyInjector;
import craft.demo.lib.model.Repository;
import craft.demo.lib.model.room.User;

public class TestFragment extends Fragment {

    private Repository mRepository;
    private TestFragmentBinding mBinding;
    private List<User> mUsers;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mBinding = TestFragmentBinding.inflate(inflater, container, false);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        mRepository = DependencyInjector.provideRepository(getContext());
        mRepository.getAllUsers().observe(getViewLifecycleOwner(), users -> {
            if (users == null || users.isEmpty()) {
                mBinding.addUsers.setEnabled(true);
                mBinding.deleteUsers.setEnabled(false);
                mBinding.updateUsers.setEnabled(false);
            } else {
                mBinding.addUsers.setEnabled(true);
                mBinding.deleteUsers.setEnabled(true);
                mBinding.updateUsers.setEnabled(true);
            }

            mUsers = users;
        });

        mBinding.addUsers.setOnClickListener(addButton -> {
            addUsers();
        });

        mBinding.updateUsers.setOnClickListener(updateButton -> {
            updateUsers();
        });

        mBinding.deleteUsers.setOnClickListener(deleteButton -> {
            deleteUsers();
        });
    }

    //This adds 10 users with random data
    private void addUsers() {
        List<User> addList = new LinkedList<>();
        for (int i = 0; i <= 9; i++) {
            Random random = new Random();
            //Generate a number between
            int score = random.nextInt(700) + 300;
            User user = new User();
            user.uid = random.nextInt(9999);
            user.score = score;
            user.name = "S:" + score;
            addList.add(user);
        }

        mRepository.insertUsers(addList);
    }

    private void updateUsers() {
        List<User> updateList = new LinkedList<>();
        int count = mUsers.size() / 4;
        count = Math.min(count, 10);
        for (int i = 0; i <= count; i++) {
            Random random = new Random();
            //Generate a number between
            int score = random.nextInt(700) + 300;
            User user = mUsers.get(i);
            user.score = score;
            updateList.add(user);
        }

        mRepository.updateUsers(updateList);
    }

    private void deleteUsers() {
        List<User> deleteList = new LinkedList<>();
        int count = mUsers.size() / 4;
        count = Math.min(count, 10);
        for (int i = 0; i <= count; i++) {
            User user = mUsers.get(i);
            deleteList.add(user);
        }

        mRepository.deleteUsers(deleteList);
    }
}
